# Model catalog

Build `../build.py` from `3DFile` to regenerate the complete deliverable, including verified printable STL exports. Each `.py` entrypoint uses cadgen decorators and shares its filename stem with its STEP. The core parametric construction is in `lib/shapes.py`; layout and nominal hardware envelopes are in `lib/assembly_layout.py`.

- Main model: `assembly.py` → `STEP/assembly.step`, `GLB/assembly.glb`.
- Service view: `internal_assembly.py` → `STEP/internal_assembly.step`.
- Part gallery: `parts_layout.py` → `STEP/parts_layout.step` (not one print bed).
- Printable components: `base`, `lid`, `battery_tray`, `electronics_deck`, `motor_cradle`, `motor_cap`, `drive_wheel`, `idler_wheel`, `bearing_spacer`, `tensioner`, `track`, `fender`, `sensor_carrier`, `front_sensor_carrier`, `io_panel`, `io_panel_blank`, `neck_mount`, `servo_cap`, `head_yoke`, `phone_frame`, `phone_top_clamp`, `qi_carrier`, `cable_clip`, `calibration_coupon`.

STEP Parts lookup results are in `../docs/catalog_search.json`. Named electronics without matching catalog CAD are deliberately labeled `_envelope`; their assumptions are in `../README_MAM_VI.md`.
