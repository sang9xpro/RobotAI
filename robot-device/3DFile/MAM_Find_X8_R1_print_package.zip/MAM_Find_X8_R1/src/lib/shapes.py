from __future__ import annotations
import math
from cadgen import build123d as bd, srgb
from . import params as p


def box(x,y,z,at=(0,0,0)):
    return bd.Pos(*at)*bd.Box(x,y,z,align=(bd.Align.CENTER,bd.Align.CENTER,bd.Align.MIN))

def cyl(r,h,at=(0,0,0)):
    return bd.Pos(*at)*bd.Cylinder(r,h,align=(bd.Align.CENTER,bd.Align.CENTER,bd.Align.MIN))

def rr(w,l,r,h,z=0):
    return bd.Pos(0,0,z)*bd.extrude(bd.RectangleRounded(w,l,r),amount=h)

def hole_x(d,length,at):
    return bd.Pos(*at)*bd.Rot(0,90,0)*bd.Cylinder(d/2,length,align=(bd.Align.CENTER,bd.Align.CENTER,bd.Align.MIN))

def hole_y(d,length,at):
    return bd.Pos(*at)*bd.Rot(90,0,0)*bd.Cylinder(d/2,length,align=(bd.Align.CENTER,bd.Align.CENTER,bd.Align.MIN))

def slot(length,width,depth,at=(0,0,0),angle=0):
    return bd.Pos(*at)*bd.Rot(0,0,angle)*bd.extrude(bd.SlotOverall(length,width),amount=depth)

def cut_all(s, tools):
    return s.cut(*tools) if tools else s

def finish(s,name,color=p.COLOR_CREAM):
    s.label=name
    s.color=srgb(color)
    return s

def base():
    s=rr(p.BODY_W,p.BODY_L,20,42,p.BASE_Z)-rr(138,168,17,44,p.BASE_Z+3)
    # Lid inserts and removable electronics deck standoffs.
    for x,y in p.LID_SCREWS:
        s=s+cyl(6.4,42,(x,y,12))
    for x,y in p.DECK_SCREWS:
        s=s+cyl(5,32,(x,y,12))
    for x,y in p.CLIFFS:
        for dx in (-11,11):
            s=s+cyl(4.2,8,(x+dx,y,12))
    tools=[]
    for x,y in p.LID_SCREWS:
        tools.append(cyl(2.1,7,(x,y,48)))
    for x,y in p.DECK_SCREWS:
        tools.append(cyl(2.1,7,(x,y,38)))
    for x,y in p.CLIFFS:
        tools.append(box(15,20,12,(x,y,11)))
        for dx in (-11,11): tools.append(cyl(1.7,10,(x+dx,y,11)))
    # Motor bracket screws, four for each motor, nuts accessible below floor.
    for side in (-1,1):
        for dx in (-8,8):
            for dy in (-11,11): tools.append(cyl(1.7,8,(side*56+dx,40+dy,10)))
        tools.append(hole_x(16,8,(side*69-4,40,28)))
        # Side fender fasteners, axes X.
        for y in (-14,14): tools.append(hole_x(3.4,12,(side*70-6,y,48)))
        # Idler axle screw head access and tension adjustment clearance.
        tools.append(hole_x(11,12,(side*70-6,-40,28)))
        # Idler tensioner fasteners, adjust along Y.
        for y in (-53,-27): tools.append(hole_x(3.4,12,(side*70-6,y,28)))
    # Battery straps and captive tray mount.
    for x in (-27,27):
        for y in (-54,-4): tools.append(box(12,3.2,8,(x,y,10)))
    for x in (-32,32):
        for y in (-50,-8): tools.append(cyl(1.7,8,(x,y,10)))
    # Front optical windows, isolated from printed wall by open air.
    for x in (-28,28):
        tools.append(box(16,12,20,(x,-84,29)))
        for dx in (-12,12): tools.append(hole_y(3.4,12,(x+dx,-78,39)))
    # Rear replaceable I/O panel and its screws.
    tools.append(box(58,10,22,(0,85,22)))
    for x in (-33,33): tools.append(hole_y(3.4,12,(x,90,33)))
    return finish(cut_all(s,tools),'base')

def lid():
    outer=bd.loft([bd.Plane.XY.offset(z)*bd.RectangleRounded(w,l,r) for z,w,l,r in [(54,144,174,20),(71,138,166,23),(84,118,144,24)]])
    inner=bd.loft([bd.Plane.XY.offset(z)*bd.RectangleRounded(w,l,r) for z,w,l,r in [(53,138,168,17),(69,132,160,20),(78,111,137,20)]])
    s=outer-inner
    for x,y in p.LID_SCREWS:
        s=s+cyl(6,7,(x,y,54))
        if x: s=s+box(12,12,7,((x+ (70 if x>0 else -70))/2,y,54))
        else: s=s+box(12,10,7,(0,80 if y>0 else -80,54))
    # Reinforcing ribs join roof around the neck load path.
    for x in (-44,38): s=s+box(8,62,8,(x,12,76))
    tools=[]
    for x,y in p.LID_SCREWS:
        tools.extend([cyl(1.7,40,(x,y,53)),cyl(3.4,33,(x,y,59))])
    for x,y in p.NECK_SCREWS: tools.append(cyl(1.7,15,(x,y,74)))
    tools.append(box(14,10,20,(-20,30,72)))
    # Cooling slots, away from phone hinge footprint.
    for x in (-30,-20,-10,0,10,20,30): tools.append(slot(15,3.2,25,(x,59,68),90))
    # Touch-pad pockets retain 2 mm roof thickness for capacitive touch.
    for x in (-36,36): tools.append(box(17,17,4,(x,-35,78)))
    return finish(cut_all(s,tools),'lid')

def battery_tray():
    s=rr(78,50,4,3)+rr(78,50,4,24)-rr(72.6,44.6,2,26,3)
    for x in (-27,27):
        for y in (-23.5,23.5): s=s-box(12,5,4,(x,y,6))
    for x in (-32,32):
        for y in (-21,21): s=s-cyl(1.7,5,(x,y,-1))
    return finish(s,'battery_tray',p.COLOR_GREEN)

def electronics_deck():
    s=rr(130,151,8,3)
    tools=[]
    for x,y in p.DECK_SCREWS: tools.append(cyl(1.7,5,(x,y,-1)))
    for x,y in p.LID_SCREWS: tools.append(cyl(6.5,5,(x,y,-1)))
    # Slotted grid for nylon standoffs / straps; no guessed board hole pattern.
    for x in (-48,-32,-16,0,16,32,48):
        for y in (-60,-42,-24,-6,12,30,48,66): tools.append(slot(12,3.4,5,(x,y,-1)))
    return finish(cut_all(s,tools),'electronics_deck',p.COLOR_GREEN)

def motor_cradle():
    s=rr(24,28,3,20)
    s=s-box(34,12.6,15,(0,0,7.7))
    for x in (-8,8):
        for y in (-11,11): s=s-cyl(1.7,23,(x,y,-1))
    return finish(s,'motor_cradle',p.COLOR_GREEN)

def motor_cap():
    s=rr(24,28,3,3)
    # 1.0 mm foam strip between this pad and motor avoids rigid overclamping.
    s=s+box(22,10,1.5,(0,0,-1.5))
    for x in (-8,8):
        for y in (-11,11): s=s-cyl(1.7,7,(x,y,-2))
    return finish(s,'motor_cap',p.COLOR_GREEN)

def wheel_common():
    s=cyl(23,26)
    s=s+cyl(24.5,2)+cyl(24.5,2,(0,0,24))
    # Track's central guide rib runs inside this groove.
    s=s-(cyl(25,3.8,(0,0,11.1))-cyl(20,3.8,(0,0,11.1)))
    for a in range(0,360,60):
        t=math.radians(a)
        s=s-cyl(3.5,28,(13*math.cos(t),13*math.sin(t),-1))
    return s

def drive_wheel():
    s=wheel_common()+cyl(7.5,7,(0,0,-6))
    # D shaft: diameter clearance 3.15; flat at 1.05 from axis.
    bore=cyl(1.575,34,(0,0,-7)) & box(6,5,36,(0,-1.45,-8))
    s=s-bore
    # M3 radial grub screw on flat, pilot to be tapped after printing.
    s=s-hole_y(2.5,10,(0,8,-2))
    return finish(s,'drive_wheel',p.COLOR_GREEN)

def idler_wheel():
    s=wheel_common()-cyl(3.2,28,(0,0,-1))
    s=s-cyl(5.1,4.3,(0,0,-0.01))-cyl(5.1,4.3,(0,0,21.8))
    return finish(s,'idler_wheel',p.COLOR_GREEN)

def bearing_spacer():
    return finish(cyl(3,17.6)-cyl(1.7,19,(0,0,-.5)),'bearing_spacer',p.COLOR_DARK)

def tensioner():
    s=rr(36,22,3,3)
    for x in (-13,13): s=s-slot(8,3.4,5,(x,0,-1))
    s=s-cyl(1.7,5,(0,0,-1))
    return finish(s,'tensioner',p.COLOR_GREEN)

def capsule(radius,thickness):
    return bd.extrude(bd.SlotCenterToCenter(80,2*radius),amount=thickness)

def track():
    ri=p.TRACK_R_IN; ro=ri+p.TRACK_SKIN
    s=capsule(ro,p.TRACK_WIDTH)-capsule(ri,p.TRACK_WIDTH+1)
    guide=bd.Pos(0,0,(p.TRACK_WIDTH-2.8)/2)*(capsule(ri+.15,2.8)-capsule(ri-2,2.8))
    s=s+guide
    # Cross treads, all attached to the belt skin. Flat sides print on XY.
    for x in range(-35,36,7):
        for sign in (-1,1): s=s+box(3.0,2.4,p.TRACK_WIDTH,(x,sign*(ro+.55),0))
    for center, start in [(40,-90),(-40,90)]:
        for a in range(start+10,start+180,20):
            t=math.radians(a)
            s=s+bd.Pos(center+(ro+.6)*math.cos(t),(ro+.6)*math.sin(t),0)*bd.Rot(0,0,a)*box(2.4,3,p.TRACK_WIDTH)
    return finish(s,'track_tpu',p.COLOR_DARK)

def fender():
    ring=capsule(32,26)-capsule(29,27)
    ring=ring & box(170,30,28,(0,29,0))
    # Local X=world Y, local Y=world Z, local Z=outwards.
    for x in (-14,14):
        tab=box(8,13,6,(x,24,-4))
        tab=tab-cyl(1.7,9,(x,20,-5))
        ring=ring+tab
    return finish(ring,'fender',p.COLOR_GREEN)

def sensor_carrier():
    s=rr(29,26,3,2.4)
    s=s-box(11,16,4,(0,0,-.5))
    # Two side rails locate a 13 x 18 mm Pololu board, leave optics open.
    for x in (-8.2,8.2): s=s+box(2.4,20,3,(x,0,2.4))
    for x in (-11,11): s=s-cyl(1.7,7,(x,0,-1))
    return finish(s,'sensor_carrier',p.COLOR_GREEN)

def front_sensor_carrier():
    s=rr(32,26,3,2.4)-box(11,16,4,(0,0,-.5))
    for x in (-8.2,8.2): s=s+box(2.4,20,3,(x,0,2.4))
    for x in (-12,12): s=s-cyl(1.7,7,(x,0,-1))
    return finish(s,'front_sensor_carrier',p.COLOR_GREEN)

def io_panel():
    s=rr(74,31,4,3)
    for x in (-33,33): s=s-cyl(1.7,5,(x,0,-1))
    # Panel-mount DC barrel jack and slide switch; removable blank is also supplied.
    s=s-cyl(4.1,5,(-19,0,-1))
    s=s-box(14,8,5,(7,0,-1))
    for x in (-3,17): s=s-cyl(1.1,5,(x,0,-1))
    s=s-cyl(3.1,5,(27,0,-1))
    return finish(s,'io_panel',p.COLOR_GREEN)

def io_panel_blank():
    s=rr(74,31,4,3)
    for x in (-33,33): s=s-cyl(1.7,5,(x,0,-1))
    return finish(s,'io_panel_blank',p.COLOR_GREEN)

def neck_mount():
    # Source coordinates are assembled world coordinates, convenient hinge datum.
    s=bd.Pos(-4,20,84)*rr(108,72,7,5)
    # Servo body clamp: shaft on right, body held with printed cap, not guessed ear holes.
    s=s+box(44,58,33,(-31,23.5,89))
    s=s-box(32.8,33.2,25,(-29,20,103.3))
    s=s-box(14,47,19,(-18.5,20,103.1))
    s=s-hole_x(18,12,(-16,12,112))
    s=s-box(8,9,10,(-50,30,106))
    # Opposed M3 pivot keeps the phone load off the servo spline alone.
    s=s+box(8,20,33,(36.5,12,89))
    s=s+hole_x(9,8,(32.5,12,122))
    s=s-hole_x(3.4,12,(30,12,112))
    for x,y in p.NECK_SCREWS: s=s-cyl(1.7,7,(x,y,83))
    for x,y in [(-49,4),(-49,48),(-13,48)]: s=s-cyl(2.1,8,(x,y,115))
    s=s-box(12,10,8,(-20,30,83))
    s=s-box(12,30,20,(-13,0,110))
    return finish(s,'neck_mount',p.COLOR_GREEN)

def servo_cap():
    s=rr(44,52,3,3)
    for x,y in [(-18,-22),(-18,22),(18,22)]: s=s-cyl(1.7,5,(x,y,-1))
    s=s-box(14,34,5,(18,-14,-1))
    return finish(s,'servo_cap',p.COLOR_GREEN)

def head_yoke():
    # Hinge center is (0,0,0); arms placed between servo and opposite pillar.
    s=box(40,14,6,(12,0,13))
    for x in (-6,30):
        arm=box(4,16,15,(x,0,0))+hole_x(9,4,(x-2,0,0))
        arm=arm-hole_x(3.4,6,(x-3,0,0))
        s=s+arm
    # Mount commercial 24T servo horn to left arm; central screw remains accessible.
    for z in (-6,6): s=s-hole_x(2.1,7,(-10,0,z))
    # Bridge toward back of phone frame. Two screws normal to phone back.
    s=s+box(36,24,8,(0,-7,12))
    for x in (-12,12): s=s-hole_y(3.4,28,(x,7,16))
    return finish(s,'head_yoke',p.COLOR_GREEN)

def phone_frame():
    s=rr(172,90,8,4)-rr(149,67,5,6,-1)
    # Clearance for Find X8 camera island; conservative envelope, not measured lens CAD.
    s=s-cyl(32,6,(-49,0,-1))
    s=s+box(68,13,4,(0,-33,0))
    for x in (-12,12): s=s-cyl(1.7,7,(x,-32,-1))
    # Join mounting holes to the lower bar with a small central mounting bridge.
    s=s+box(34,17,4,(0,-33.5,0))
    for x in (-12,12): s=s-cyl(1.7,7,(x,-32,-1))
    for x in (-61,61):
        s=s+box(16,4,12,(x,-39.5,4))
        s=s+box(16,7,2.5,(x,-38,14))
    for x in (-80,80): s=s-slot(11,3.4,7,(x,39,-1),90)
    # Qi carrier connects at two slotted points on right edge (no metal behind coil).
    for y in (-18.5,25.5): s=s-slot(8,3.4,7,(80,y,-1),90)
    s=s-cyl(32,6,(-49,0,-1))
    return finish(s,'phone_frame',p.COLOR_CREAM)

def phone_top_clamp():
    s=rr(172,8,3,4)
    for x in (-80,80): s=s-cyl(1.7,6,(x,0,-1))
    for x in (-61,61):
        s=s+box(16,4,8,(x,-2.5,4))
        s=s+box(16,7,2.5,(x,-3.5,10))
    return finish(s,'phone_top_clamp',p.COLOR_GREEN)

def qi_carrier():
    # 56 mm puck recess, mounting disk left open on contact side; removable clamps.
    s=cyl(31,9)-cyl(28.4,8,(0,0,2))
    s=s-cyl(22,4,(0,0,-1))
    for y in (-22,22):
        s=s+box(53,8,3,(38,y,0))
        s=s-slot(16,3.4,6,(63,y,-1))
    s=s-box(10,8,12,(0,-29,-1))
    # Clear the phone frame lower cross-brace while preserving rear puck support.
    s=s-box(74,20,7,(-17,-38.5,4.6))
    s=s-box(68,8,7,(0,33.5,4.6))
    for y in (-22,22):
        s=s+cyl(4,2,(63,y,3))
        s=s-slot(16,3.4,8,(63,y,-1))
    s=s-cyl(28.4,8,(0,0,2))
    return finish(s,'qi_carrier',p.COLOR_GREEN)

def cable_clip():
    s=rr(18,12,3,3)-cyl(1.7,5,(-5,0,-1))
    s=s+box(8,12,4,(4,0,3))-box(10,5,2,(4,0,3))
    return finish(s,'cable_clip',p.COLOR_GREEN)

def calibration_coupon():
    s=rr(80,35,3,4)
    for i,d in enumerate((3.0,3.1,3.2,3.4,4.0,4.2,4.4,10.0,10.2)):
        x=-32+(i%5)*16; y=-8+(i//5)*16
        s=s-cyl(d/2,6,(x,y,-1))
    return finish(s,'calibration_coupon',p.COLOR_CREAM)

FACTORIES={n:globals()[n] for n in ['base','lid','battery_tray','electronics_deck','motor_cradle','motor_cap','drive_wheel','idler_wheel','bearing_spacer','tensioner','track','fender','sensor_carrier','front_sensor_carrier','io_panel','io_panel_blank','neck_mount','servo_cap','head_yoke','phone_frame','phone_top_clamp','qi_carrier','cable_clip','calibration_coupon']}

def print_shape(name):
    s=FACTORIES[name]()
    if name=='lid': s=s.rotate(bd.Axis.X,180)
    if name=='motor_cap': s=s.rotate(bd.Axis.X,180)
    if name=='head_yoke': s=s.rotate(bd.Axis.Y,90)
    # Lay the fender on its flat side; track already has the correct side down.
    bb=s.bounding_box()
    return s.moved(bd.Location((0,0,-bb.min.Z)))
