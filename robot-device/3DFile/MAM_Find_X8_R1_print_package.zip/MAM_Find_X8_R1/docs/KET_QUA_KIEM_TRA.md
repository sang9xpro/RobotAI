# Kết quả kiểm tra — MẦM R1 / Find X8

Đơn vị mm; bản CAD để chế tạo mẫu. Chưa in hoặc chạy robot thật.

## Hình học đã kiểm tra

- 24/24 STEP chi tiết hợp lệ, một khối kín mỗi file, thể tích dương, đáy Z=0, kích thước XY vừa 220 × 220 mm (`geometry_checks.json`).
- 24/24 STL cuối kín, một thành phần liên thông, không báo sai đơn vị và không có kết quả đo thiếu (`dfam/summary.json`).
- Kiểm tra mọi cặp khối trong assembly, bỏ qua hình mắt trang trí: không còn giao cứng >0,1 mm³. Bốn giao bánh/xích TPU khoảng 405,128 mm³/cặp là tải trước hướng kính 0,3 mm có chủ ý. Cần thử lực căng thực tế.
- 29 đường trục vít đã thử trên STEP lưu bằng hình trụ Ø3: không bị vật liệu chắn >0,01 mm³ (`mating_checks.json`). Chưa mô hình hóa đầy đủ đầu vít, ê-cu, long đen và khoảng thao tác tua vít.
- Các góc cổ −10°, −5°, 0°, +5°, +10° không giao cứng >0,1 mm³. Góc −15° có va chạm khung điện thoại với gá cổ (~16,45 mm³); +15° không va chạm trong mô hình. Giới hạn vận hành ban đầu ±10°, không suy diễn thành chứng nhận toàn bộ hành trình liên tục (`motion_checks.json`).
- Đã xem ảnh xuất từ STEP của 24 chi tiết, cụm lắp trước/sau, cụm mở nắp và bảng chi tiết. Khớp cổ, đường xích, lỗ camera và các gá hiện rõ. Ảnh trong `previews/` là ảnh CAD, không phải ảnh robot đã lắp.

## Độ dày và hỗ trợ in

Nguồn giới hạn: bảng FDM/FFF trong skill `dfam-check/references/process-limits.md` (bản sao `dfam_process_limits.md`): thành có đỡ ≥1,2 mm; thành tự đứng ≥1,6 mm; góc tự đỡ ≥45° so với phương ngang. Đây là mặc định bảo thủ; máy và filament thực tế chưa xác định. Dữ liệu đo ở `dfam/<tên>.json`, trường `wall_thickness.min_mm`, `wall_thickness.p05_mm`, `overhangs.down_facing_area_below_limit_pct`. Mỗi STL lấy tối đa 2.500 mẫu ray-cast; không phải phép chứng minh mọi điểm đều đủ dày.

- 23 chi tiết có p05 ≥1,864 mm, vượt cả ngưỡng 1,2 và 1,6 mm. Một số giá trị min nhỏ tại mép/giao tuyến (xem bảng dưới) cần kiểm tra preview lớp in; không coi p05 đạt là chứng nhận bền cơ học.
- **Ống đệm in `bearing_spacer`: p05=min=1,299 mm. Đạt ngưỡng có đỡ 1,2 nhưng không đạt ngưỡng thành tự đứng 1,6.** Bộ lắp khuyến nghị dùng **2 ống đệm kim loại dài 17,6 mm, ID khoảng 3,2–3,4 mm, OD vừa vòng trong ổ 623ZZ**. File nhựa chỉ để thử fit. Nếu muốn dùng FDM, phải tăng thành lên ≥1,6 mm, mở rộng lỗ tâm bánh tương ứng và đảm bảo hai đầu ống chỉ tỳ vòng trong, rồi kiểm tra lại; không đơn giản tăng OD vì có thể cọ phớt ổ.
- Đối với phần nhô ngang: cần support cục bộ theo slicer. Báo cáo diện tích là phần trăm tổng diện tích mặt, không phải tỷ lệ khối lượng support hay thời gian in.

### Hướng in có thể giảm support

Kết quả từ `dfam/*_orientations.json`, mục `orientations.candidates`. Sau xoay phải dùng “drop to bed” trong slicer.

| Chi tiết | Phương án so với STL gốc | Diện tích cần đỡ | Chiều cao in |
|---|---|---|---|
| drive_wheel | Lật 180° quanh X, mặt ngoài xuống | 17,2% → 5,2% | 32 → 32 mm |
| head_yoke | Xoay +90° quanh X | 9,1% → 4,7% | 50 → 27 mm |
| fender | Lật 180° quanh X | 4,3% → 1,7% | 30 → 30 mm |

Các phương án chỉ tối ưu diện tích support trong sáu hướng trục; cần xét độ bền theo lớp, bám bàn và chất lượng lỗ. Với yoke chịu tải, ưu tiên độ bền và in thử trước khi đổi hướng.

## Chưa xác minh

Kích thước/điện áp/dòng N20 đang có; dev board ESP32 hay module rời; vị trí chính xác tai và trục servo mua thực tế; ốp điện thoại/camera thật; puck Qi; mã bo nguồn và cổng/công tắc. Các khối mua ngoài chưa rõ model là vùng dự trù, không phải đảm bảo mua bất kỳ module nào cũng lắp vừa. Chưa kiểm tra tải, nhiệt, tuổi thọ, độ bám, chống lật hoặc phản ứng chống rơi trên phần cứng.

## Bảng đo STL

| Chi tiết | min (mm) | p05 (mm) | Diện tích cần đỡ (%) |
|---|---:|---:|---:|
| base | 0.23 | 2.998 | 0.6 |
| battery_tray | 2.401 | 2.7 | 0.7 |
| bearing_spacer | 1.299 | 1.299 | 0.0 |
| cable_clip | 2.0 | 2.0 | 4.8 |
| calibration_coupon | 4.0 | 4.0 | 0.0 |
| drive_wheel | 2.0 | 3.575 | 17.2 |
| electronics_deck | 1.604 | 3.0 | 0.0 |
| fender | 0.819 | 2.946 | 4.3 |
| front_sensor_carrier | 2.4 | 2.4 | 0.0 |
| head_yoke | 2.303 | 2.798 | 9.1 |
| idler_wheel | 2.0 | 4.468 | 5.5 |
| io_panel | 1.22 | 3.0 | 0.0 |
| io_panel_blank | 2.656 | 3.0 | 0.0 |
| lid | 1.394 | 2.913 | 4.6 |
| motor_cap | 1.302 | 2.224 | 0.0 |
| motor_cradle | 1.302 | 1.864 | 0.0 |
| neck_mount | 0.6 | 2.5 | 0.8 |
| phone_frame | 0.178 | 4.0 | 0.6 |
| phone_top_clamp | 2.303 | 2.5 | 2.2 |
| qi_carrier | 0.824 | 2.0 | 0.1 |
| sensor_carrier | 1.857 | 2.4 | 0.0 |
| servo_cap | 2.305 | 3.0 | 0.0 |
| tensioner | 1.002 | 3.0 | 0.0 |
| track | 2.391 | 2.4 | 3.1 |
